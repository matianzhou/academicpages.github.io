#include <RcppArmadillo.h>
#include <Rcpp.h>
//#include <Rmath.h>
#include <vector>
#include <string>
#include <random>
//#include <boost/math/common_factor.hpp>
#include <boost/math/distributions/inverse_gamma.hpp>
#include <boost/math/distributions/normal.hpp>
#include <boost/math/distributions/negative_binomial.hpp>
#include <boost/random.hpp>
#include <boost/random/gamma_distribution.hpp>
#include <boost/regex.hpp>
#include <boost/random/variate_generator.hpp>
#include <algorithm>

//#include <gsl/gsl_rng.h>
//#include <gsl/gsl_randist.h>
//#include <gsl/gsl_blas.h>
//#include <RcppGSL.h>
//#include <gsl/gsl_rng.h> //Things to improve: deal with dyn.load and use gsl and helloPG to speed up
//#include <./helloPG/src/helloPG.cpp>

// Enable C++11 via this plugin (Rcpp 0.10.3 or later)
// [[Rcpp::plugins(cpp11)]]
// [[Rcpp::depends(BH)]]
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::depends(RcppGSL)]]

using namespace std;
using namespace Rcpp;

const double lambdaMean = 0;
const double lambdaVar = 5;
const double etaMean = -8; 
const double etaVar = 5; 
const double mMean = -3; 
const double mVar = 5; 
const double thetaMean = 5; 
const double thetaVar = 5; 


// 1. Define some specific distributions

//arma::vec rInvGamma(const int n,const double shape, const double scale){
//    boost::random::mt19937 rng;
//    boost::gamma_distribution<> gd( shape );
//    boost::variate_generator<boost::mt19937&,boost::gamma_distribution<> > var_gamma( rng, gd );
//    arma::vec v = arma::zeros<arma::vec>(n);
//    for (int i = 0; i<n; i++){
//        v(i) = scale/(var_gamma()) ;
//    }
//    return v;
//}

arma::vec rmvnorm(const arma::vec& mu, const arma::mat& sigma) {
  int ncols = sigma.n_cols;
  arma::vec Y = arma::randn<arma::vec>(ncols);
  arma::vec out =  mu + (Y.t() * arma::chol(sigma)).t();
  return out ;
}

const double log2pi = log(2.0 * M_PI);

double dmvnorm(const arma::rowvec& x, const arma::rowvec& mean, const arma::mat& sigma, bool logd = false) {
  int xdim = x.n_cols;
  double out;

  arma::mat rooti = arma::trans(arma::inv(arma::trimatu(arma::chol(sigma))));
  double rootisum = arma::sum(log(rooti.diag()));
  double constants = -(static_cast<double>(xdim)/2.0) * log2pi;
  arma::vec z = rooti * arma::trans( x - mean) ;
  out = constants - 0.5 * arma::sum(z%z) + rootisum;
  
  if (logd == false) {
    out = exp(out);
  }
  return out;
}

double dnormLog(const double x, const double mean, const double sd){
  boost::math::normal_distribution<> my_normal(mean,sd);
  double out = log(boost::math::pdf(my_normal,x));
  return out;
}

double dnbinomLog(const double x, const double size, const double mu){
  double prob = size/(size+mu);
  boost::math::negative_binomial_distribution<> my_neg_binom(int(size),prob);
  double out = log(boost::math::pdf(my_neg_binom,x));
  return out;
}


//arma::vec rDirichlet(const arma::vec& alpha) {
//    int n = alpha.size();
//    arma::vec out(n);
    // Allocate random number generator
//    gsl_rng *r = gsl_rng_alloc(gsl_rng_mt19937);
//    gsl_ran_dirichlet(r, n, alpha.begin(), out.begin());
    // Release random number generator
//    gsl_rng_free(r);
//    return out;
//}


// 2. Updating functions 

double updatePi (const arma::vec& delta,const int G){
    arma::vec out(2);
    arma::vec tmpAlpha(2);
    double tmp = sum(delta);
    tmpAlpha(0)=1 + tmp;
    tmpAlpha(1)=1 + G - tmp;
//    out = rDirichlet(tmpAlpha);
    double out1 = rbeta(1,tmpAlpha(0),tmpAlpha(1))(0);
    //double out1;
    //out1 = arma::as_scalar(out(0));
    return out1;
}

double updateSigma2DESeq(const arma::vec& es, const arma::vec& lambda, 
                      const arma::vec& delta){

    arma::vec shape(es.size());
    arma::vec scale(es.size());
  for(int i=0; i<es.size(); i++){
    
    shape(i) = delta[i];
    scale(i) = delta[i]*(es[i]- delta[i]*lambda[i])*(es[i]- delta[i]*lambda[i]);
  }
    double out = 1/rgamma(1,sum(shape)/2.0, sum(scale)/2.0)(0);
    return out;
}


double updateSigma2DEArray(const arma::vec& es, const arma::vec& lambda, 
                      const arma::vec& delta){
  
  arma::vec shape(es.size());
  arma::vec scale(es.size());
  for(int i=0; i<es.size(); i++){
    
    shape(i) = delta[i];
    scale(i) = delta[i]*(es[i]- delta[i]*lambda[i])*(es[i]- delta[i]*lambda[i]);
  }
  
  double out = 1/rgamma(1,sum(shape)/2 + 1.0, sum(scale)/2 + 1.0)(0);
  return out;
}


double updateSigma2NonDESeq(const arma::vec& es, const arma::vec& delta){
  int count=0;
  int G = delta.size();
  for(int i=0; i<G;i++){
    if(delta(i)==0){
      count++;
    }
  }
  double shape= double(count)/2.0+ 1.0;
  double scale = as_scalar((1-delta).t() * square(es))/2.0  + 10.0;
  //simulation + 1, + 1
  double out = 1/rgamma(1,shape,scale)(0);
  return out;
}

double updateSigma2NonDEArray(const arma::vec& es, const arma::vec& delta){
  int count=0;
  int G = delta.size();
  for(int i=0; i<G;i++){
    if(delta(i)==0){
      count++;
    }
  }
  double shape= double(count)/2.0+ 10.0;
  double scale = as_scalar((1-delta).t() * square(es))/2.0  + 1.0;
  //simulation + 1, + 1
  double out = 1/rgamma(1,shape,scale)(0);
  return out;
}


double updateLambda(const arma::vec& es, const double lambda, const arma::vec& delta, 
                    const arma::mat& sigma, const arma::vec& norm, 
                    const double lambdaMean, const double lambdaVar){
    arma::vec corEs;
    corEs = es - norm;
    double oldLogp, oldHyper, oldLogLike, newLambda, newLogp, newHyper, newLogLike;
    oldLogp = dmvnorm(corEs.t(), lambda*delta.t(), sigma, true);
    oldHyper = dnormLog(lambda, lambdaMean, sqrt(lambdaVar));
    oldLogLike = oldLogp + 2*oldHyper;
    newLambda = as_scalar(lambdaMean + sqrt(lambdaVar)*arma::randn(1));
    newLogp = dmvnorm(corEs.t(), newLambda*delta.t(), sigma, true);
    newHyper = dnormLog(newLambda, lambdaMean, sqrt(lambdaVar));
    newLogLike = newLogp + 2*newHyper;
    double cut = log(as_scalar(arma::randu(1)));
    if( (newLogLike - oldLogLike) > cut){
            return newLambda;
    }
    else{
        return lambda;
    }
}

arma::vec updateAlphaBeta (const arma::vec& y, const arma::vec& lib, 
                           const arma::mat& xMat, const arma::vec& omega, 
                           const double logphi, const int delta, const double lambda, 
                           const double sigma2DE, const double sigma2NonDE, 
                           const double etaMean, const double etaVar){
    arma::mat Omega = arma::diagmat(omega);
    double r = 1.0/exp(logphi);
    arma::vec c(2);
    c(0) = etaMean;
    c(1) = (lambda*delta);
    arma::mat C = arma::zeros<arma::mat>(2,2);
    C(0,0) = etaVar;
    if(delta==1){
        C(1,1) = sigma2DE;
    }
    else{
        C(1,1) = sigma2NonDE;
    }
    arma::mat V = inv( xMat.t()*Omega*xMat + inv(C) );
    arma::vec z = (y-r)/(2*omega) - lib;
    arma::vec m = V*( (xMat.t())*Omega*z + inv(C)*c);
    arma::vec out = rmvnorm (m, V);
    return out;
}

double updateB (const arma::vec& y, const arma::vec& x, const double a, 
                const double lambda, const int delta, const double sigma2DE, 
                const double sigma2NonDE, const double tau2){
    arma::vec yEffect(x.size());
    int yIdx=0;
    for(int i=0; i<x.size(); i++){
        if(x(i)==1){
            yEffect(yIdx) = y(i);
            yIdx++;
        }
    }
    yEffect.resize(yIdx);
    int nEffect = yIdx;
    double sigma2Beta;
    if(delta==1){
        sigma2Beta=double(sigma2DE);
    }
    else{
        sigma2Beta=double(sigma2NonDE);
    }
    double tmpMean = (lambda*delta/sigma2Beta + sum(yEffect-a)/tau2) / 
                       (1.0/sigma2Beta + double(nEffect)/tau2);
    double tmpVar = 1.0/(1.0/sigma2Beta + double(nEffect)/tau2);
    double out = arma::as_scalar(tmpMean + sqrt(tmpVar)*arma::randn(1));
    return out;
}

double updateA (const arma::vec& y, const arma::vec& x, const double b, 
                const double tau2, const double thetaMean, const double thetaVar){
    double n = double(x.size());
    double tmpMean = (thetaMean/thetaVar + sum(y - b*x)/tau2) / (1.0/thetaVar + n/tau2);
    double tmpVar =  1.0/(1.0/thetaVar + n/tau2);
    double out = arma::as_scalar(tmpMean + sqrt(tmpVar)*arma::randn(1));
    return out;
}

double updateLogphi (const double m, const double kappa, const double logphi, 
                     const double alpha, const double beta, const arma::vec& x, 
                     const arma::vec& y, const arma::vec& lib, const double mMean, 
                     const double mVar){
    double oldLogp = 0;
    double tmpSize = 1;
    if(round(1.0/exp(logphi))>0){
      tmpSize = round(1.0/exp(logphi));
    }
     for (int i=0; i<y.size(); i++){
       double Psi= lib(i) + alpha + beta*x(i);
       oldLogp += R::dnbinom_mu(y(i), tmpSize , exp(Psi), TRUE);
     }

    
    double oldHyper = dnormLog(logphi, m, sqrt(kappa)); 
    double oldLogLike = oldLogp + oldHyper;
    
    double newLogphi =  arma::as_scalar(mMean + sqrt(mVar)*arma::randn(1));

    while(newLogphi < -10){
      newLogphi = arma::as_scalar(mMean + sqrt(mVar)*arma::randn(1));
    }
    
    double newLogp = 0;

    double tmpSizeNew = 1;
    if(round(1.0/exp(newLogphi))>0){
       tmpSizeNew = double(round(1.0/exp(newLogphi)));
    }

      for (int i=0; i<y.size(); i++){
          double Psi= lib(i) + alpha + beta*x(i);
          newLogp += R::dnbinom_mu(y(i), tmpSizeNew, exp(Psi), TRUE);
      }

    double newHyper = dnormLog(newLogphi, m, sqrt(kappa));
    double newLogLike = newLogp + newHyper;

    double cut = log(arma::as_scalar(arma::randu(1)));
    if( (newLogLike - oldLogLike) > cut){
        return newLogphi;
    }
    else{
        return logphi;
    }
}

double updateM (const arma::vec& logphi, const double kappa, const double mMean, 
                const double mVar, const int G){
    double tmpMean = (mMean/mVar + sum(logphi)/kappa) / (1.0/mVar + G/kappa);
    double tmpVar = 1.0/(1.0/mVar + G/kappa);
    double out  = arma::as_scalar(tmpMean + sqrt(tmpVar)*arma::randn(1));
    return out;
}

//double updateKappa(arma::vec logphi, double m, const int G){
double updateKappa(const arma::vec& logphi, const double m, const int G){
    double shape=G/2.0 + 1.0;
    double scale = sum( square(logphi-m) )/2.0 + 10.0;
    double out = 1/rgamma(1,shape,scale)(0);
    return out;
}

double updateTau2 (const arma::vec& ygk, const double agk, const double bgk, 
                   const arma::vec& x){ 
  int n = x.size();
  double scale=(sum(square(ygk - agk - bgk*x)))/2.0 ;
  double out  = 1/rgamma(1, double(n)/2.0+10.0, scale + 1)(0);
  return out;
}


double updateDeltaBeta(const double deltaOld, const double beta, 
                          const double Sigma2DE, const double Sigma2NonDE,
                          const double lambda){
    //    arma::vec x = xSeq[index];
    double deltaNew = 1-deltaOld;
    double oldLogp=0;
    if(deltaOld==0){
        oldLogp += dnormLog(beta, 0, sqrt(Sigma2NonDE));
    }
    else{
        oldLogp += dnormLog(beta, lambda, sqrt(Sigma2DE));
    }

    double newLogp=0;
    if(deltaNew==0){
        newLogp += dnormLog(beta, 0, sqrt(Sigma2NonDE));
    }
    else{
        newLogp += dnormLog(beta, lambda, sqrt(Sigma2DE));
    }
    double oldLogLike = oldLogp;
    double newLogLike = newLogp;
    double cut = log(as_scalar(arma::randu(1)));
    if( (newLogLike - oldLogLike) > cut ){
       return(deltaNew) ;
    }
    else{
       return(deltaOld) ;
    }
}

double updateDeltaB(const double deltaOld, const double b, 
                       const double Sigma2DE, const double Sigma2NonDE,
                       const double lambda){
  //    arma::vec x = xSeq[index];
  double deltaNew = 1-deltaOld;
  double oldLogp=0;
  if(deltaOld==0){
    oldLogp += dnormLog(b, 0, sqrt(Sigma2NonDE));
  }
  else{
    oldLogp += dnormLog(b, lambda, sqrt(Sigma2DE));
  }
  
  double newLogp=0;
  if(deltaNew==0){
    newLogp += dnormLog(b, 0, sqrt(Sigma2NonDE));
  }
  else{
    newLogp += dnormLog(b, lambda, sqrt(Sigma2DE));
  }
  double oldLogLike = oldLogp;
  double newLogLike = newLogp;
  double cut = log(as_scalar(arma::randu(1)));
  if( (newLogLike - oldLogLike) > cut ){
    return(deltaNew) ;
  }
  else{
    return(deltaOld) ;
  }
}


// [[Rcpp::export]]
Rcpp::List initialize(Rcpp::List dataList, arma::vec seqIdxOld, arma::vec arrayIdxOld, 
                      Rcpp::List xSeq, Rcpp::List xArray,  int G, arma::vec N, 
                      int seed, Rcpp::Function f){
  srand(seed);
  //    int K= seqIdx.size() + arrayIdx.size();
  arma::vec arrayIdx = arrayIdxOld-1;
  arma::vec seqIdx = seqIdxOld-1;
  int KSeq = seqIdx.size();
  int KArray = arrayIdx.size();
  int K = KSeq + KArray;
  arma::vec deltaInit = arma::zeros<arma::vec>(K*G);
  for(int i=0; i<G; i++){
    arma::vec delta = Rcpp::rbinom(K, 1, 0.5);
      deltaInit.subvec((i*K), ((i+1)*K-1)) = delta ;
  }
  
// #ifdef BOOST_NO_NUMERIC_LIMITS_LOWEST
//  int max_digits10 = 2 + (boost::math::policies::digits<double, boost::math::policies::policy<> >() * 30103UL) / 100000UL;
//  cout << "BOOST_NO_NUMERIC_LIMITS_LOWEST is defined" << endl;
// #else
//  int max_digits10 = std::numeric_limits<double>::max_digits10;
// #endif
//  cout << "Show all potentially significant decimal digits std::numeric_limits<double>::max_digits10 = "
//       << max_digits10 << endl;
//  cout.precision(max_digits10);
  
  arma::vec sigma2DEInit=1/rgamma(K,1,1);
  arma::vec sigma2NonDEInit=1/rgamma(K,10,1);
  arma::vec tau2Init=1/rgamma((KArray*G), 10,1);
  arma::vec lambdaInit= Rcpp::rnorm(G, lambdaMean, sqrt(lambdaVar));
  
  arma::vec esInit = arma::zeros<arma::vec>(K*G);
  arma::vec alphaInit = arma::zeros<arma::vec>(KSeq*G);
  arma::vec logphiInit = alphaInit;
  arma::vec aInit = arma::zeros<arma::vec>(KArray*G);
  
  arma::vec mInit = Rcpp::rnorm(KSeq, mMean, mVar);
  arma::vec kappaInit = 1/rgamma(KSeq,1,1);
  
  arma::mat covEs = arma::zeros<arma::mat>(K,K);
  covEs.diag()=sigma2NonDEInit;
  for(int i=0; i<G; i++){
    esInit.subvec((i*K),((i+1)*K-1)) = rmvnorm(  
      lambdaInit(i) *  deltaInit.subvec(i*K,(i+1)*K-1), covEs );
    
    arma::vec tmpMean(KSeq);
    tmpMean.fill(etaMean);
    arma::mat tmpVar= arma::zeros<arma::mat>(KSeq, KSeq);
    tmpVar.diag().fill(etaVar);
    alphaInit.subvec( (i*KSeq), (i+1)*KSeq-1 ) = rmvnorm(tmpMean, tmpVar);
    
    tmpMean.fill(mMean);
    tmpVar.diag().fill(mVar);
    logphiInit.subvec( (i*KSeq), (i+1)*KSeq-1 ) = rmvnorm(tmpMean, tmpVar);
    
    arma::vec tmpMean2(KArray);
    tmpMean2.fill(thetaMean);
    arma::mat tmpVar2= arma::zeros<arma::mat>(KArray, KArray);
    tmpVar2.diag().fill(thetaVar);
    aInit.subvec( (i*KArray), (i+1)*KArray-1 ) = rmvnorm( tmpMean2, tmpVar2);
  }
  
  Rcpp::List omegaInit(KSeq);
  for (int k=0; k<KSeq; k++ ){
    arma::mat omegaTmp = arma::zeros<arma::mat>( G, N(seqIdx(k)) );
    arma::vec tmp(N(seqIdx(k)));
    tmp.fill(0);
    for(int g=0; g<G; g++){
      arma::mat tmpMat = Rcpp::as<arma::mat>(dataList[seqIdx(k)]);
      omegaTmp.row(g) = Rcpp::as<arma::vec>(f(N(seqIdx(k)), 
                              tmpMat.row(g)+1/exp(mMean) , tmp)).t();
    }
    omegaInit[k] = omegaTmp;
  }
  
  Rcpp::List init;
  
//  init["Prob.DE"]=piInit;
  init["Delta"]=deltaInit;
  init["Sigma2.DE"]=sigma2DEInit;
  init["Sigma2.Non.DE"]=sigma2NonDEInit;
  init["Lambda"]=lambdaInit;
  init["ES"]=esInit;
  init["Alpha"] = alphaInit;
  init["LogPhi"] = logphiInit;
  init["A"] = aInit;
  init["M"] =mInit ;
  init["Kappa"] = kappaInit;
  init["Tau2"] = tau2Init;
  init["Omega"] = omegaInit;
  return init;
}


// [[Rcpp::export]]
Rcpp::List MHGibbs(const Rcpp::List count, const Rcpp::List intensity, 
                   const arma::vec& seqIdxOld, const arma::vec& arrayIdxOld, 
                   const Rcpp::List xSeq, const Rcpp::List xArray, const int G, 
                   const arma::vec& N, const Rcpp::List logT, const arma::mat& normMat, 
                   const Rcpp::List init, const int iteration, const int seed, const Rcpp::Function rpg){
  
  arma::vec arrayIdx = arrayIdxOld-1;
  arma::vec seqIdx = seqIdxOld-1;
  int KSeq = seqIdx.size();
  int KArray = arrayIdx.size();
  int K = KSeq + KArray;
  
// #ifdef BOOST_NO_NUMERIC_LIMITS_LOWEST
//  int max_digits10 = 2 + (boost::math::policies::digits<double, boost::math::policies::policy<> >() * 30103UL) / 100000UL;
//  cout << "BOOST_NO_NUMERIC_LIMITS_LOWEST is defined" << endl;
// #else
//  int max_digits10 = std::numeric_limits<double>::max_digits10;
// #endif
//  cout << "Show all potentially significant decimal digits std::numeric_limits<double>::max_digits10 = "
//       << max_digits10 << endl;
//  cout.precision(max_digits10);
  
  //    double pi = init["Prob.DE"];
  arma::vec delta = Rcpp::as<arma::vec>(init["Delta"]);
  arma::vec sigma2DE = Rcpp::as<arma::vec>(init["Sigma2.DE"]);
  arma::vec sigma2NonDE = Rcpp::as<arma::vec>(init["Sigma2.Non.DE"]);
  arma::vec lambda = Rcpp::as<arma::vec>(init["Lambda"]);
  arma::vec es = Rcpp::as<arma::vec>(init["ES"]);
  arma::vec alpha = Rcpp::as<arma::vec>(init["Alpha"]);
  arma::vec logphi=Rcpp::as<arma::vec>(init["LogPhi"]);
  arma::vec a = Rcpp::as<arma::vec>(init["A"]);
  arma::vec m = Rcpp::as<arma::vec>(init["M"]);
  arma::vec kappa = Rcpp::as<arma::vec>(init["Kappa"]);
  arma::vec tau2 = Rcpp::as<arma::vec>(init["Tau2"]);
  Rcpp::List omega = init["Omega"];
  
  //convert lists to fields
  arma::field<arma::vec> xSeqField(KSeq,1);
  arma::field<arma::vec> logTField(KSeq,1);
  arma::field<arma::mat> countField(KSeq,1); // transposed
  arma::field<arma::mat> intensityField(KArray,1); //transposed
  arma::field<arma::mat> omegaField(KSeq,1); // transposed
  arma::field<arma::mat> omegaCurField(KSeq,1); //transposed
  arma::field<arma::vec> xArrayField(KArray,1);
  
  for(int k=0; k<KSeq; k++){
    countField(k,0) = Rcpp::as<arma::mat>(count[k]).t();
    xSeqField(k,0) = Rcpp::as<arma::vec>(xSeq[k]);
    logTField(k,0) = Rcpp::as<arma::vec>(logT[k]);
    omegaField(k,0) = Rcpp::as<arma::mat>(omega[k]).t();
  }
  for (int k=0; k<KArray; k++){
    intensityField(k,0) = Rcpp::as<arma::mat>(intensity[k]).t();
    xArrayField(k,0) = Rcpp::as<arma::vec>(xArray[k]);
  }
  
  arma::mat stateDelta(K*G, iteration);
  stateDelta.col(0)=delta;
  arma::mat stateES(K*G, iteration);
  stateES.col(0)=es;
  arma::mat stateLambda(G, iteration);
  stateLambda.col(0)=lambda;
  arma::mat stateAlpha(KSeq*G, iteration);
  stateAlpha.col(0)=alpha;
  arma::mat stateLogphi(KSeq*G, iteration);
  stateLogphi.col(0)=logphi;
  arma::mat stateM(KSeq, iteration);
  stateM.col(0) = m;
  arma::mat stateKappa(KSeq, iteration);
  stateKappa.col(0) = kappa;
  
  arma::mat stateSigma2DE(K, iteration);
  arma::mat stateSigma2NonDE(K, iteration);
  arma::mat stateA(KArray*G, iteration);
  arma::mat stateTau2(KArray*G, iteration);
  stateSigma2DE.col(0).fill(0);
  stateSigma2NonDE.col(0).fill(0);
  stateTau2.col(0).fill(0);
  
  //Start iteration
  //    arma::vec piVec(K);
  //arma::mat deltaMat(K,G);
  arma::vec esCur(K*G);
  arma::vec betaCur(KSeq*G);
  arma::vec bCur(KArray*G);
  arma::vec alphaCur(KSeq*G);
  arma::vec logphiCur(KSeq*G);
  arma::vec mCur(KSeq);
  arma::vec kappaCur(KSeq);
  arma::vec aCur(KArray*G);
  arma::vec lambdaCur(G);
  
  arma::mat covDEg;
  arma::mat covNonDEg;
  
  for (int iter=1; iter<iteration; iter++){
    srand(seed+iter);
    cout << "Iteration: "<< iter+1 << endl;
    
    esCur.fill(0);
    betaCur.fill(0);
    bCur.fill(0);
    alphaCur.fill(0);
    logphiCur.fill(0);
    mCur.fill(0);
    kappaCur.fill(0);
    aCur.fill(0);
    lambdaCur.fill(0);
    
    covDEg = arma::diagmat(sigma2DE);
    covNonDEg = arma::diagmat(sigma2NonDE);
    omegaCurField = omegaField;
    
    for(int g=0; g<G; g++){
      arma::vec deltaG = delta.subvec(g*K,(g+1)*K-1);
      arma::vec esG = es.subvec(g*K,(g+1)*K-1);
      arma::vec betaG(KSeq);
      for (int j=0; j<KSeq; j++){
        betaG(j) = esG(seqIdx(j));
      }
      arma::vec bG(KArray);
      for (int j=0; j<KArray; j++){
        bG(j) = esG(arrayIdx(j));
      }
      arma::vec alphaG = alpha.subvec(g*KSeq,(g+1)*KSeq-1);
      arma::vec logphiG = logphi.subvec(g*KSeq,(g+1)*KSeq-1);
      arma::vec phiG = exp(logphiG);
      arma::vec aG = a.subvec(g*KArray,(g+1)*KArray-1);
      double lambdaG = lambda(g);
      arma::vec tau2G = tau2.subvec(g*KArray,(g+1)*KArray-1);
      arma::vec normG = normMat.row(g).t();
      
      for(int k=0; k<KSeq; k++){
        int idx = seqIdx(k);
        arma::mat xMat(N(idx), 2, arma::fill::ones);
        xMat.col(1) = xSeqField(k,0);
        arma::vec alphaBeta = updateAlphaBeta( countField(k,0).col(g), logTField(k,0), 
                                               xMat, omegaField(k,0).col(g), logphiG(k), 
                                               deltaG(idx), lambdaG, sigma2DE(idx), 
                                               sigma2NonDE(idx), etaMean, etaVar );
    
        if( (abs(alphaBeta(1))>10) || (abs(alphaBeta(0))>30)  ){
          alphaCur(g*KSeq+k) = alphaG(k);
          esCur(g*K+idx) = betaG(k);
          betaCur(g*KSeq+k) = betaG(k);
        }
        else{
          alphaCur(g*KSeq+k) = alphaBeta(0);
          esCur(g*K+idx) = alphaBeta(1);
          betaCur(g*KSeq+k) = alphaBeta(1);
        }
        arma::vec tmpH = countField(k,0).col(g) + 1.0/exp(logphiG(k));
        Rcpp::NumericVector tmpH2 = Rcpp::NumericVector(tmpH.begin(),tmpH.end());
        arma::vec tmpZvec(2);
        tmpZvec(0) = alphaCur(g*KSeq+k);
        tmpZvec(1) = esCur(g*K+idx);
        arma::vec tmpZ = xMat*tmpZvec + logTField(k,0);
        Rcpp::NumericVector tmpZ2 = Rcpp::NumericVector(tmpZ.begin(),tmpZ.end());
        
        omegaCurField(k,0).col(g) = Rcpp::as<arma::vec>( rpg( N(idx), tmpH2, tmpZ2) );
        
        logphiCur(g*KSeq+k) = updateLogphi( m(k), kappa(k), logphiG(k), alphaCur(g*KSeq+k), 
                                     betaCur(g*KSeq+k), xSeqField(k,0),  countField(k,0).col(g), 
                                     logTField(k,0), mMean, mVar);
      }
      
      for(int k=0; k<KArray; k++){
        int idx = arrayIdx(k);
        double tmp = updateB( intensityField(k,0).col(g), xArrayField(k,0), aG(k), 
                              lambdaG, int(deltaG(idx)), sigma2DE(idx), sigma2NonDE(idx), 
                              tau2G(k) );
        
        esCur(g*K+idx) = tmp;
        //                if (isnan(tmp)){
        //  cout << "tmp iter" << iter << " " << g << " " <<k  <<endl;
        //  cout << Rcpp::as<arma::vec>(xArray[k]).has_nan() << " " << aG(k) << " " << lambdaG << " " << int(deltaG(idx)) << " " << sigma2DE(idx) << " " << sigma2NonDE(idx) << " " << tau2G(k) <<endl;
        //}
        bCur(g*KArray+k) = tmp;
        aCur(g*KArray+k) = updateA( intensityField(k,0).col(g), xArrayField(k,0), 
                               tmp, tau2G(k), thetaMean, thetaVar );
      }
      
      if(sum(deltaG)==0){
        lambdaCur(g) = as_scalar(lambdaMean + sqrt(lambdaVar)*arma::randn(1));
      }
      else{
        lambdaCur(g) = updateLambda(esCur.subvec(g*K, (g+1)*K-1), 
                           lambdaG, deltaG, covDEg, normG,lambdaMean,lambdaVar);
      }
    }
    
    for(int k=0; k<KSeq; k++){
      arma::vec tmpLogphi(G);
      for(int i=0; i<G; i++){
        tmpLogphi(i) = logphiCur(k+KSeq*i);
      }
      mCur(k) = updateM( tmpLogphi, kappa(k), mMean, mVar, G);
      kappaCur(k) = updateKappa( tmpLogphi, mCur(k), G );
    }
    
    es = esCur;
    stateES.col(iter) = es;
    alpha = alphaCur;
    stateAlpha.col(iter) = alpha;
    logphi = logphiCur;
    stateLogphi.col(iter) = logphi;
    m = mCur;
    stateM.col(iter) = m;
    kappa = kappaCur;
    stateKappa.col(iter) = kappa;
    a = aCur;
    stateA.col(iter) = a;
    lambda = lambdaCur;
    stateLambda.col(iter) = lambda;
    omegaField = omegaCurField;
    
    arma::vec tau2Cur(G*KArray);
    for (int g=0; g<G; g++){
      for (int k=0; k<KArray; k++){
        double tmpIdx = g*KArray+k;
        tau2Cur(tmpIdx) = updateTau2( intensityField(k,0).col(g), aCur(tmpIdx), 
                                       bCur(tmpIdx), xArrayField(k,0) );
      }
    }

    tau2 = tau2Cur;
    stateTau2.col(iter)=tau2;
    
    arma::vec sigma2DECur = arma::zeros<arma::vec>(K);
    arma::vec sigma2NonDECur = arma::zeros<arma::vec>(K);
    
    for (int k=0; k<K; k++){
      arma::vec deltaK(G);
      arma::vec esK(G);
      for (int i=0; i<G; i++){
        deltaK(i) = delta(k+i*K);
        esK(i) = esCur(k+i*K);
      }
      if(std::find(std::begin(seqIdx), std::end(seqIdx), k) != std::end(seqIdx)) {
       sigma2DECur(k) = updateSigma2DESeq(esK, lambdaCur, deltaK);
       sigma2NonDECur(k) = updateSigma2NonDESeq(esK, deltaK);
     } else {
       sigma2DECur(k) = updateSigma2DEArray(esK, lambdaCur, deltaK);
       sigma2NonDECur(k) = updateSigma2NonDEArray(esK, deltaK);
     }
  }

    sigma2DE = sigma2DECur;
    sigma2NonDE = sigma2NonDECur;
    stateSigma2DE.col(iter) = sigma2DE;
    stateSigma2NonDE.col(iter) = sigma2NonDE; // from now it might gives error that cholesky decomposition failed.
    
    arma::vec deltaBBetaCur = arma::zeros<arma::vec>(G*K);
    for (int g=0; g<G; g++){
      for (int k=0; k<KSeq; k++){
        int tmpIdx=g*KSeq + k;
        int tmpIdxLong = g*K + seqIdx(k);
        deltaBBetaCur(tmpIdxLong) = updateDeltaBeta( delta(tmpIdxLong) , 
                                        betaCur(tmpIdx), sigma2DECur(seqIdx(k)),  
                                        sigma2NonDECur(seqIdx(k)), lambdaCur(g) );
      }

      for (int k=0; k<KArray; k++){
        int tmpIdx=g*KArray + k;
        int tmpIdxLong = g*K + arrayIdx(k);
        deltaBBetaCur(tmpIdxLong) = updateDeltaB( delta(tmpIdxLong), 
                                       bCur(tmpIdx), sigma2DECur(arrayIdx(k)),  
                                       sigma2NonDECur(arrayIdx(k)), lambdaCur(g)) ;
      }
    }
     delta = deltaBBetaCur;
     stateDelta.col(iter)= delta;

  } // end of MCMC sampling
  
  Rcpp::List state;
  
  state["Delta"] = stateDelta;
  state["ES"] = stateES;
  state["Lambda"] = stateLambda ;
//  state["Alpha"] = stateAlpha;
//  state["LogPhi"] = stateLogphi;
//  state["Sigma2.DE"] = stateSigma2DE ;
//  state["Sigma2.Non.DE"] = stateSigma2NonDE ;
//  state["A"] = stateA;
//  state["Tau2"] = stateTau2;
//  state["M"] = stateM;
//  state["Kappa"] = stateKappa;
  
  cout << "MH Gibbs sampling complete." <<endl;
  return state;
}

