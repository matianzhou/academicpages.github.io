##' Function to run MCMC chain 
##' The \code{RunMCMC} is a function to run the MCMC chain
##' @title Function to run MCMC chain   
##' @param Data.list is a list of K elements, where K is the number of studies, 
##' each element is a microarray or RNAseq expression matrix with 
##' G rows and N columns, where G is number of matched genes and N 
##' is the sample size.
##' @param X.list is a list of K elements, each element includes is 
##' a phenotypic condition of the corresponding samples, with case=1, control=0.
##' @param norm.mat is a matrix of normalization factors, with K columns and G rows. 
##' @param index.seq index for RNA-seq studies
##' @param index.array index for microarray studies
##' @param iteration is the number of MCMC chains wish to run 
##' @param seed is a initial seed for random number generator. 
 
##' @return a list of MCMC output matrices for three key parameters of
##' interest: the DE indicator "Delta", the study-specific effect size
##' "ES", and the grand mean effect size "Lambda". For details, please
##' refer to the paper "A joint Bayesian modeling for integrating 
##' microarray and RNA-seq transcriptomic data"

##' @export
##' @examples
##' \dontrun{
##' data(SimData)
##' G <- nrow(Data.list[[1]])
##' adjust.seq1 <-  adjust.seq2 <- adjust.array1 <-  adjust.array2 <- rep(0,G)
##' ## For simulation, we already know the normalization factor:
##' adjust.array1[1:200] <- adjust.array2[1:200] <- -0.25
##' adjust.array1[201:400] <- adjust.array2[201:400] <- 0.25
##' norm.mat <- cbind(adjust.seq1,adjust.seq2,adjust.array1,
##' adjust.array2)
##' index.seq <- 1:2
##' index.array <- 3:4
##' iteration <- 2000
##' MCMC.out <- RunMCMC(Data.list, X.list, norm.mat, index.seq,
##'                     index.array, iteration)
##' }

RunMCMC <- function(Data.list, X.list, norm.mat,
                    index.seq, index.array,
                    iteration, seed=15213) {
  
  set.seed(seed)
  X.seq <- X.list[index.seq]
  X.array <- X.list[index.array]
  G <- sapply(Data.list,nrow)[1]
  N <- sapply(Data.list,ncol)
  
  init<-initialize(Data.list,index.seq, index.array, X.seq, X.array, G, N, seed,BayesLogit::rpg)
  
  count <- Data.list[index.seq]
  intensity <- Data.list[index.array]
  logsum<-function(x){
    log(colSums(data.matrix(x)))
  }
  logT<-lapply(count,logsum)  ## library size 
  
  
  MCMCout <- MHGibbs(count, intensity,index.seq, index.array, 
                     X.seq, X.array,G,N, logT, norm.mat, 
                     init, iteration,seed, BayesLogit::rpg)  
  
  return(MCMCout)
  
}


