##' Function to calculate the normalization factors
##' The \code{NormDiff} is a function to calculate the normalization factors
##' @title Function to calculate the normalization factors   
##' @param test.es is a matrix of logFC from the test data (i.e. other than 
##' the reference data)
##' @param ref.es is a vector of logFC from the reference data
##' @param cutoff is a logFC threshold to select the gene set for calculating 
##' the normalization factors
##' @return a vector of length K-1 of normalization factors for the test data, 
##' the normalization factor for the reference data is just zero.

##' @export
##' @examples
##' \dontrun{
##' data(RealSubset)
##' G <- nrow(Data.list[[1]])
##' K <- 4
##' index_seq <- 1
##' index_array <- 2:4
##' count <- Data.list[index_seq]
##' intensity <- Data.list[index_array]
##' X_seq <- X.list[index_seq]
##' X_array <- X.list[index_array] 
##' es_seq=function (x,lib,k) {
##'   x=array(x)
##'   v1=log((x[which(X_seq[[k]]==1)]+1)/(lib[which(X_seq[[k]]==1)]))
##'   v2=log((x[which(X_seq[[k]]==0)]+1)/(lib[which(X_seq[[k]]==0)]))
##'   u=mean(v1) - mean(v2)
##'   return(u)
##' }
##' beta.obs<-matrix(,nrow=G,ncol=length(index_seq))
##' for (k in 1:length(index_seq)){
##'  lib<-colSums(count[[k]])
##'  for (i in 1:G){
##'    beta.obs[i,k]<-es_seq(x=count[[k]][i,],lib=lib,k=k)
##'  }
##' }

##' es_array=function (x,k) {
##'  x <- as.numeric(x)
##'  v1 <- x[which(X_array[[k]]==1)]
##'  v2 <- x[which(X_array[[k]]==0)]
##'  u=mean(v1)- mean(v2)
##'  return(u)
##' }

##' b.obs<-matrix(,nrow=G,ncol=length(index_array))
##' for (k in 1:length(index_array)){
##'  for (i in 1:G){
##'    b.obs[i,k]<-es_array(x=intensity[[k]][i,],k=k)
##'  }
##' }
##' es.obs <- cbind(beta.obs,b.obs)
##' rownames(es.obs) <- rownames(Data.list[[1]])
##' up.index <- which(es.obs[,1]>0  &  es.obs[,2]>0 & es.obs[,3]>0 & 
##' es.obs[,4]>0) 
##' down.index <- which(es.obs[,1]<0 &  es.obs[,2]<0 &  es.obs[,3]<0 & 
##' es.obs[,4]<0)

##' test.es <- abs(es.obs[c(up.index,down.index),2:4])
##' ref.es <- abs(es.obs[c(up.index,down.index),1])
##' cutoff <- 0.2
##' norm.factor <- NormDiff(test.es=test.es,ref.es=ref.es,cutoff=cutoff)

##' ## Further make into a matrix to input into MCMC
##' norm.mat <- matrix(0,nrow=G,ncol=K)
##' norm.mat[which(es.obs[,2]>0),2] <- -norm.factor[1]
##' norm.mat[which(es.obs[,3]>0),3] <- -norm.factor[2]
##' norm.mat[which(es.obs[,4]>0),4] <- -norm.factor[3]
##' norm.mat[which(es.obs[,2]<0),2] <- norm.factor[1]
##' norm.mat[which(es.obs[,3]<0),3] <- norm.factor[2]
##' norm.mat[which(es.obs[,4]<0),4] <- norm.factor[3]
##' }

NormDiff <- function(test.es,ref.es,cutoff) {
   K <- ncol(test.es) + 1 ## ref can only have one
   Kmin <- K%/%2+1 
   es <- cbind(test.es,ref.es)
   Torder=apply(abs(es),1,FUN=function(x) sort(x)[Kmin] )
   select.ind <- which(Torder >= cutoff)
   ref.select <- ref.es[select.ind]		
   test.select <- test.es[select.ind,]
   p.out <- norm.out <- rep(NA,ncol(test.select))		
  for (j in 1:ncol(test.select)) {
  	dat <- data.frame(logFC=c(ref.select,test.select[,j]),
  	                  group=c(rep("ref",length(ref.select)),
  	                          rep("test",length(test.select[,j]))))
  	sum.dat <- summary(lm(logFC ~ as.factor(group),data=dat))
  	p.out[j] <- sum.dat$coef[2,4]
  	norm.out[j] <- ifelse(p.out[j] < (0.05/K),
  	                 abs(median(dat$logFC[which(dat$group=='ref')])-
  	                     median(dat$logFC[which(dat$group=='test')]) ) , 0 )
  }
  return(norm.out)
}

