##' Function to run parallel MCMC chain 
##' The \code{parMCMC} is a function to run the MCMC chain
##' @title Function to run MCMC chain   
##' @param Data.list is a list of K elements, where K is the number of studies, 
##' each element is a microarray or RNAseq expression matrix with 
##' G rows and N columns, where G is number of matched genes and N 
##' is the sample size.
##' @param X.list is a list of K elements, each element includes is 
##' a phenotypic condition of the corresponding samples, with case=1, control=0.
##' @param norm.mat is a matrix of normalization factors, with K columns and G rows. 
##' @param index.seq index for RNA-seq studies
##' @param index.array index for microarray studies
##' @param iteration is the number of MCMC chains wish to run 
##' @param chunks is the number of cpu's called 
##' @param seed is a initial seed for random number generator. 

##' @return a list of MCMC output matrices for three key parameters of
##' interest: the DE indicator "Delta", the study-specific effect size
##' "ES", and the grand mean effect size "Lambda". For details, please
##' refer to the paper "A joint Bayesian modeling for integrating 
##' microarray and RNA-seq transcriptomic data"

##' @export
##' @examples
##' \dontrun{
##' data(SimData)
##' G <- nrow(Data.list[[1]])
##' adjust.seq1 <-  adjust.seq2 <- adjust.array1 <-  adjust.array2 <- rep(0,G)
##' ## For simulation, we already know the normalization factor:
##' adjust.array1[1:200] <- adjust.array2[1:200] <- -0.25
##' adjust.array1[201:400] <- adjust.array2[201:400] <- 0.25
##' norm.mat <- cbind(adjust.seq1,adjust.seq2,adjust.array1,
##' adjust.array2)
##' index.seq <- 1:2
##' index.array <- 3:4
##' iteration <- 2000
##' MCMC.out <- parMCMC(Data.list, X.list, norm.mat, index.seq,
##'                     index.array, iteration, chunks=2)
##' }

parMCMC <- function(Data.list, X.list, norm.mat,
                    index.seq, index.array,
                    iteration, chunks, seed=15213) {
  sfInit(parallel=T,cpus=chunks,type="SOCK")
  set.seed(seed)
  G <- sapply(Data.list,nrow)[1]
  orig.gene <- rownames(Data.list[[1]])
  K <- length(Data.list)
  N <- sapply(Data.list,ncol)
  cv.out <- cvFolds(G,K=chunks)
  data.sub <- vector('list',length=chunks)
  
  for (i in 1:chunks) {
    data.sub[[i]] <- lapply(1:K,FUN=function(x) Data.list[[x]][which(cv.out$which==i),]) 
  }
  G.sub<- sapply(1:chunks,FUN=function(x) nrow(data.sub[[x]][[1]]))
  norm.sub <- vector('list',length=chunks)
  for (i in 1:chunks) {
    norm.sub[[i]]<- norm.mat[which(cv.out$which==i),]
  }
  
  cv.gene <- unlist(sapply(1:chunks,FUN=function(x) rownames(data.sub[[x]][[1]]),simplify=F))

  parWrapper <- function(data.step, data.sub) {
    
    data <- data.sub[[data.step]]	
    norm <- norm.sub[[data.step]]
    MCMC.out <- RunMCMC(Data.list=data, X.list=X.list, norm.mat=norm, 
                        index.seq=index.seq,index.array=index.array, 
                        iteration=iteration)  
    return(MCMCout)
  }
  sfExport("parWrapper") 
  sfExport("data.sub")
  sfExport("norm.sub")
  sfExport("X.list")
  sfExport("index.seq")
  sfExport("index.array")
  sfExport("iteration")

  result<-sfLapply(1:chunks, function(xxx) {
    parWrapper(xxx, data.sub = data.sub) 
  } )
  
  sfStop()
  
  MCMCout <- vector("list",3)
  names(MCMCout) <- c("Delta","ES","Lambda")
  tmp <- vector("list",chunks)

  for(j in 1:3) { ## 3 parameters outputted: Delta,ES,Lambda 
    for(i in 1:chunks){
      tmp[[i]] <- result[[i]][[j]]
    }
    mat <- do.call("rbind", tmp)
    rownames(mat) <- cv.gene
    MCMCout[[j]] <- mat[orig.gene,]
  }
  
  return(MCMCout)
}


