GetHeatMap <-
function(cluster.top) {
  library(gplots)
  start <- proc.time()
  if(!is.matrix(cluster.top))
    stop ("Assignment needs to be a matrix")
  
  diss.mat <- matrix(,nrow=nrow(cluster.top),ncol=nrow(cluster.top))
  for (i in 1:nrow(diss.mat)) {
    for (j in 1:ncol(diss.mat)){
      diss.mat[i,j] <- sum(sapply(1:ncol(cluster.top),FUN=function(x) cluster.top[i,x] %in% cluster.top[j,x]))/ncol(cluster.top)    
    }
  }
  hm.cor<-heatmap.2(diss.mat, symm=T,main=NULL,cexCol=0.1,cexRow=0.1,scale='none',symbreaks=T,
                    Rowv = TRUE,Colv = TRUE,
                    key=T, keysize=1,symkey=F, dendrogram=c('both'),density.info="none", trace="none",
                    col=bluered,breaks=seq(0,1,by=0.001))  
  end <- proc.time()
   print(end-start)
}
