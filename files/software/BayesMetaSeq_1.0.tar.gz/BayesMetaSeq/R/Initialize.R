Initialize <-
function(Data.list,X.list,lambda_mean,
          lambda_var,eta_mean,eta_var,
           m_mean,m_var,IG_alpha,IG_beta,
           C_init,pi_alpha,
     epsilon_omega = 0.5, epsilon_phi = 0.5,
     epsilon_log_phi = -0.5, cov_tune = 1e-3,seed=12345) {

library(BayesMetaSeq)
library(MCMCpack)
library(mvtnorm)
library(BayesLogit)
library(gtools)
library(gdata)
library(msm)

  mat.sqrt<-function(A)         #square root of a matrix
  {
    ei<-eigen(A)
    d<-ei$values
    d<-(d+abs(d))/2
    d2<-sqrt(d)
    ans<-ei$vectors %*% diag(d2) %*% t(ei$vectors)
    return(ans)
  }
  
  
  mat.sqrt.inv<-function(A)   #square root inverse of a matrix
  {
    ei<-eigen(A)
    d<-ei$values
    d<-(d+abs(d))/2
    d2<-1 / sqrt(d)
    d2[d == 0]<-0
    ans<-ei$vectors %*% diag(d2) %*% t(ei$vectors)
    return(ans)
  }
  
  rescale<-function(x,newrange) {
    if(nargs() > 1 && is.numeric(x) && is.numeric(newrange)) {
      # if newrange has max first, reverse it
      if(newrange[1] > newrange[2]) {
        newmin<-newrange[2]
        newrange[2]<-newrange[1]
        newrange[1]<-newmin
      }
      xrange<-range(x)
      if(xrange[1] == xrange[2]) stop("can't rescale a constant vector!")
      mfac<-(newrange[2]-newrange[1])/(xrange[2]-xrange[1])
      invisible(newrange[1]+(x-xrange[1])*mfac)
    }
    else {
      cat("Usage: rescale(x,newrange)\n")
      cat("\twhere x is a numeric object and newrange is the min and max of the new range\n")
    }
  }
  
  set.seed(seed)
  
  G <- sapply(Data.list,nrow)[1]  # number of genes
  N <- sapply(Data.list,ncol)    # number of samples
  K <- length(Data.list) # number of studies
  
  libsize <- sapply(Data.list,colSums)
  logT <- lapply(libsize,log)
  
  v_alpha=v_beta=v_phi=K+1
  
  #1. pi (for each cluster c)    
  c.init<-sample(1:C_init,size=G,replace=T)   
  pi.init<-rdirichlet(1, alpha=as.vector(pi_alpha+table(c.init) ) )
  
  #2. delta   
  delta.init<-rep(0,K*G)  
  for (i in 1:G){
    delta.init[((i-1)*K+1):(i*K)]<-as.vector(rbinom(n=K,size=1,prob=pi.init))
  }
  
  #3. corr
  rho.cov<-rwish(v=v_beta,S=diag(1,nrow=K,ncol=K))
  rho.cor<-mat.sqrt.inv(diag(x=diag(rho.cov))) %*% rho.cov %*% mat.sqrt.inv(diag(x=diag(rho.cov)))
  rho.init.de<-rho.init.non.de<-rho.cor[which(upper.tri(rho.cor)=='TRUE')]
  
  r.cov<-rwish(v=v_alpha,S=diag(1,nrow=K,ncol=K))
  r.cor<-mat.sqrt.inv(diag(x=diag(r.cov))) %*% r.cov %*% mat.sqrt.inv(diag(x=diag(r.cov)))
  r.init<-r.cor[which(upper.tri(r.cor)=='TRUE')]
  
  t.cov<-rwish(v=v_phi,S=diag(1,nrow=K,ncol=K))
  t.cor<-mat.sqrt.inv(diag(x=diag(t.cov))) %*% t.cov %*% mat.sqrt.inv(diag(x=diag(t.cov)))
  t.init<-t.cor[which(upper.tri(t.cor)=='TRUE')]
  
  #4. sigma2
  sigma2.de.init<- rinvgamma(K, shape=IG_alpha, scale=IG_beta)
  sigma2.non.de.init<- rinvgamma(K, shape=IG_alpha, scale=IG_beta)
  tau2.init<- rinvgamma(K, shape=IG_alpha, scale=IG_beta)
  xi2.init <- rinvgamma(K, shape=IG_alpha, scale=IG_beta)
  
  #5. grand mean
  lambda.init<-rnorm(G,mean=lambda_mean,sd=sqrt(lambda_var))
  eta.init<-rnorm(G,mean=eta_mean,sd=sqrt(eta_var))
  m.init<-rnorm(G,mean=m_mean,sd=sqrt(m_var)) 
  
  #6. main model
  beta.init<-rep(0,K*G)
  alpha.init<-rep(0,K*G)
  logphi.init<-rep(0,K*G)
  
  for (g in 1:G) {  
    Cov.beta<- mat.sqrt(diag(sigma2.non.de.init))%*% rho.cor %*% 
      mat.sqrt(diag(sigma2.non.de.init))
    Cov.alpha<- mat.sqrt(diag(tau2.init))%*% r.cor %*% 
      mat.sqrt(diag(tau2.init))
    Cov.logphi<- mat.sqrt(diag(xi2.init))%*% t.cor %*% 
      mat.sqrt(diag(xi2.init))
    
    beta.init[((g-1)*K+1):(g*K)]<-as.vector( rmvnorm(n=1,
                                                     mean=delta.init[((g-1)*K+1):(g*K)]*lambda.init[g],
                                                     sigma=Cov.beta ) )
    alpha.init[((g-1)*K+1):(g*K)]<-as.vector( rmvnorm(n=1,
                                                      mean=rep(eta.init[g],K),
                                                      sigma=Cov.alpha  ) )
    logphi.init[((g-1)*K+1):(g*K)]<-as.vector( rmvnorm(n=1,
                                                       mean=rep(m.init[g],K),
                                                       sigma=Cov.logphi ) )
  }  
  
  #7. omega
  
  omega.init <- vector('list',length=K)
  
  for (k in 1:K) {
    omega.init[[k]] <- matrix(,nrow=G,ncol=N[k])
  }
  for (k in 1:K) {
    for (g in 1:G) {
      omega.init[[k]][g,]<-rpg(num=N[k],h=as.numeric(Data.list[[k]][g,])+1/exp(m.init[g]),z=0)
    }  
  }
  
  init=list(Cluster.Assign=c.init,
            Prob.Cluster=pi.init,
            Delta=delta.init,
            Rho.DE=rho.init.de,
            Rho.Non.DE=rho.init.non.de,
            RR=r.init,
            TT=t.init,
            Sigma2.DE=sigma2.de.init,
            Sigma2.Non.DE=sigma2.non.de.init,
            Tau2=tau2.init,
            Xi2=xi2.init,
            Lambda=lambda.init,
            Eta=eta.init,
            M=m.init,
            Beta=beta.init,
            Alpha=alpha.init,
            LogPhi=logphi.init,
            Omega=omega.init
  )
  
  print("MCMC chain initialized")
  return(init)
  
}
