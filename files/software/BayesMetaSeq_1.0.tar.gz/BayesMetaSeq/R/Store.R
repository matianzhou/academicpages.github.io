Store <-
function(Data.list,X.list,iteration,thin)  {
  
  G <- sapply(Data.list,nrow)[1]  # number of genes
  N <- sapply(Data.list,ncol)    # number of samples
  K <- length(Data.list) # number of studies
  L<- 3^K ## number of differential patterns (3 = + / 0 / - )
  
  c.assign <- matrix(rep(0,G*(iteration/thin+1)),nrow=G,ncol=(iteration/thin+1))  
  pi<- vector(mode='list',length=(iteration/thin+1))
  delta <- matrix(rep(0, K*G*iteration),nrow=K*G,ncol=iteration)  
  
  sigma2.de <- matrix(rep(0,K*iteration),nrow=K,ncol=iteration)
  sigma2.non.de <- matrix(rep(0,K*iteration),nrow=K,ncol=iteration)
  tau2 <- matrix(rep(0,K*iteration),nrow=K,ncol=iteration)
  xi2<- matrix(rep(0,K*iteration),nrow=K,ncol=iteration)
  
  rho.de <- matrix(rep(0,((K*(K-1))/2)*iteration),nrow=(K*(K-1))/2,ncol=iteration)
  rho.non.de <- matrix(rep(0,((K*(K-1))/2)*iteration),nrow=(K*(K-1))/2,ncol=iteration)
  r <- matrix(rep(0,((K*(K-1))/2)*iteration),nrow=(K*(K-1))/2,ncol=iteration)
  t <- matrix(rep(0,((K*(K-1))/2)*iteration),nrow=(K*(K-1))/2,ncol=iteration)
  
  lambda<-matrix(rep(0,G*iteration),nrow=G,ncol=iteration)   
  eta<-matrix(rep(0,G*iteration),nrow=G,ncol=iteration)   
  m<-matrix(rep(0,G*iteration),nrow=G,ncol=iteration)   
  
  beta<-matrix(rep(0,K*G*iteration),nrow=K*G,ncol=iteration)
  alpha<-matrix(rep(0,K*G*iteration),nrow=K*G,ncol=iteration)
  logphi<-matrix(rep(0,K*G*iteration),nrow=K*G,ncol=iteration)
  
  omega <- vector('list',length=K)
  
  for (k in 1:K) {
    omega[[k]] <- matrix(,nrow=G,ncol=N[k])
  }
  
  store <- list(Cluster.Assign=c.assign,
                Prob.Cluster=pi,
                Delta=delta,
                Rho.DE=rho.de,
                Rho.Non.DE=rho.non.de,
                RR=r,
                TT=t,
                Sigma2.DE=sigma2.de,
                Sigma2.Non.DE=sigma2.non.de,
                Tau2=tau2,
                Xi2=xi2,
                Lambda=lambda,
                Eta=eta,
                M=m,
                Beta=beta,
                Alpha=alpha,
                LogPhi=logphi,
                Omega = omega
  )
  print("Store matrix is ready")
  return(store)
}
