DPM <- function(Data.list, Delta, C_init, pi_alpha, iteration, thin, seed=12345) {
  
    library(mvtnorm)
    libsize <- lapply(Data.list,colSums) # library size
    logT <- lapply(libsize,log) # log scale library size
	G <- sapply(Data.list,nrow)[1]  # number of genes
    S <- sapply(Data.list,ncol)    # number of samples in each study
    K <- length(Data.list) # number of studies
    X.list <- lapply(1:K,FUN=function(k) {
    	c(rep(1,S[k]/2),rep(0,S[k]/2)) }   )   ## balanced phenotypic condition
  
  es_seq =function (y,X,lib) {
    y=array(y)
    v1=log((y[which(X==1)]+1)/(lib[which(X==1)]))
    v2=log((y[which(X==0)]+1)/(lib[which(X==0)]))
    u=mean(v1-v2)
    return(u)
  }
  
  beta.obs<-matrix(rep(0,G*K),nrow=G,ncol=K) 
  for (g in 1:G){
    for (k in 1:K){
      lib<-libsize[[k]]
      beta.obs[g,k]<-es_seq(y=Data.list[[k]][g,],X=X.list[[k]],lib=lib)
    }
  }
  
  update_c <- function(z.mat,c.assign,i) {
    
    ## delta.accum.mat is a matrix of G rows and L columns, every row would sum to thin (e.g. =50)
    
    cluster.pool<-c(unique(c.assign),max(unique(c.assign))+1)
    z.i <- z.mat[i,]
    
    prob.c <- sapply(unique(c.assign), FUN=function(x) {
      cluster.size <- length(which(c.assign==x))
      cluster.ind <- which(c.assign==x)
      if(cluster.size>1) {z.ave.cluster <- apply(z.mat[cluster.ind,],2,mean)} else{
        z.ave.cluster <- z.mat[cluster.ind,]}
      
      ifelse(cluster.size!=0, 
             ( (cluster.size-1) /(G-1+pi_alpha) ) * 
               dmvnorm(x=z.i,mean=(cluster.size/(cluster.size+1))*z.ave.cluster,sigma=diag((cluster.size+2)/(cluster.size+1),K),log=F) , 
             0)},simplify=T )
    
    
    
    prob.jump <- ( pi_alpha/(G-1+pi_alpha) ) *
      dmvnorm(x=z.i,mean=rep(0,K),sigma=diag(2,K),log=F)
    
    
    # prob.c is a vector of length = length(unique(c)) 
    std.prob <- c(prob.c,prob.jump)/(sum(prob.c)+prob.jump) 
    sample(cluster.pool,size=1,prob=std.prob)
  }
  
  
  ClusterOut <- matrix(rep(0,G*(iteration/thin+1)),nrow=G,ncol=(iteration/thin+1))
  set.seed(seed)
  ClusterOut[,1] <- sample(1:C_init,size=G,replace=T)  
  sign.vector<-c(apply(beta.obs,1,sign))   
  
  #out <- matrix(rep(0,G*(iteration/thin+1)),nrow=G,ncol=(iteration/thin+1))
  #out[,1] <- ClusterOut[,1]
 
   for (iter in 1:iteration) {    
        set.seed(seed+iter)      
    if(iter %% thin==0) {
      start <- proc.time()
      rnd = iter/thin
      c.assign.old <- ClusterOut[,rnd]
      prob.vector <- apply(Delta[,(1+thin*(rnd-1)):(thin+thin*(rnd-1))],1,mean)
      scale.prob.vector <-  (prob.vector*sign.vector+1)/2  
      z.vec <- qnorm(scale.prob.vector) 
      z.vec[which(z.vec> 3)] <- 4
      z.vec[which(z.vec< -3)] <- -4
      z.mat <- matrix(z.vec,byrow=T,nrow=G,ncol=K)  ## observed data for clustering
      c.assign.cur<-rep(0,G)
      for (g in 1:G) {
        c.assign.cur[g]<-update_c(z.mat=z.mat,c.assign=c.assign.old, i=g)
      }
           end <- proc.time()
           print(end-start)
           print(rnd)
      print(table(c.assign.cur))

      ClusterOut[,rnd+1] <- c.assign.cur      
    } 
  }

 return(ClusterOut)
	
	
	
}

