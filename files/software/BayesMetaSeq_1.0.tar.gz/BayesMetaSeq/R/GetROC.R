GetROC <-
function(all,delta.cut,method,data,true.ind,false.ind) {
  
  rownames(data) <- paste("gene",c(1:nrow(data)),sep='')
  
  if(!is.numeric(all)) 
    stop ("all must be numbers")
  
  if(length(all)>nrow(data) )
    stop ("all number cannot exceed total number of rows")
  
  if(method %in% c("Bayes","Fisher")==F) 
    stop ("unknown method")
  
  if(!is.numeric(true.ind)) 
    stop ("true index must be numbers")
  
  if(!is.numeric(false.ind)) 
    stop ("false index must be numbers")
  
  if(method=='Bayes') {
    TP <- TN <- c()
    for (k in 1:ncol(data)) {
      pos.name<-names(sort(data[,k],decreasing=T))[which(sort(data[,k],decreasing=T)>=(1-delta.cut))]
      neg.name<-names(sort(data[,k],decreasing=T))[which(sort(data[,k],decreasing=T)<(1-delta.cut))]
      tp.name<-pos.name[which(pos.name %in% paste('gene',true.ind,sep='')==T)]
      tn.name<-neg.name[which(neg.name %in% paste('gene',false.ind,sep='')==T)]
      TP<-union(TP,tp.name)
      TN<-ifelse(length(TN)>tn.name,TN,tn.name)
    }
    sens<-ifelse(length(TP)>=length(true.ind),1,length(TP)/length(true.ind))
    spec<-ifelse(length(TN)>=length(false.ind),1,length(TN)/length(false.ind))
    return(c(sens,spec))
  }
  
  else if(method=='Fisher') {
    
    fisher<-function(x) {
      f<-sum(-2*log(x))
      1-pchisq(f,df=2*length(x))
    }
    p_fisher<-apply(data,1,fisher)
    pos.name<-names(sort(p_fisher,decreasing=F))[1:all]
    neg.name<-names(sort(p_fisher,decreasing=F))[-c(1:all)]
    tp.name<-pos.name[which(pos.name %in% paste('gene',true.ind,sep='')==T)]
    tn.name<-neg.name[which(neg.name %in% paste('gene',false.ind,sep='')==T)]
    sens<-ifelse(length(tp.name)>=length(true.ind),1,length(tp.name)/length(true.ind))
    spec<-ifelse(length(tn.name)>=length(false.ind),1,length(tn.name)/length(false.ind))
    return(c(sens,spec))
  }
  
}
