GetPower <-
function(top,method,data,true.ind) {
  
  rownames(data) <- paste("gene",c(1:nrow(data)),sep='')
  
  if(!is.numeric(top)) 
    stop ("top must be numbers")
  
  if(length(top)>nrow(data) )
    stop ("top number cannot exceed total number of rows")
  
  if(method %in% c("Bayes","Fisher")==F) 
    stop ("unknown method")
  
  if(!is.numeric(true.ind)) 
    stop ("true index must be numbers")
  
  if(method=='Bayes') {
    TP <- c()
    for (k in 1:ncol(data)) {
      DE.name<-names(sort(data[,k],decreasing=T))[1:top]
      TP.name <- DE.name[which(DE.name %in% paste('gene',true.ind,sep='')==T)]
      TP<- union(TP,TP.name)
    }
    if(length(TP)>=top) {return(top)}
    else return(length(TP))
  }
  
  else if(method=='Fisher') {
    
    fisher<-function(x) {
      f<-sum(-2*log(x))
      1-pchisq(f,df=2*length(x))
    }
    p_fisher<-apply(data,1,fisher)
    
    DE.name<-names(sort(p_fisher,decreasing=F))[1:top]
    TP <- DE.name[which(DE.name %in% paste('gene',true.ind,sep='')==T)]
    if(length(TP)>=top) {return(top)}
    else return(length(TP))
  }
  
}
