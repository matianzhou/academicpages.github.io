GetBayesianQ <-
function(Delta,G,K,burnin) {
  
  ## Delta is a matrix of G*K rows and iteration columns
  
  if(!is.matrix(Delta)) 
    stop ("Delta must be a matrix")
  
  if(nrow(Delta)!=G*K )
    stop ("Check your Delta matrix, Delta is a matrix of G*K rows and iteration columns")
  
  if(ncol(Delta) <= burnin) 
    stop ("Cannot discard all iterations")
  
  lfdr <- rep(NA,G)
  for (g in 1:G) {
    mat <- Delta[(K*(g-1)+1):(K*(g-1)+K),-c(1:burnin)]
    delta<-apply(mat,2,sum)
    lfdr[g] <- length(delta[which(delta==0)])/(ncol(Delta)-burnin)
  }
  
  t<-seq(0.001,1,0.001)
  FDR_t <- rep(NA,length(t))
  for (i in 1:length(t)){
    FDR_t[i] <- sum(lfdr*as.numeric(lfdr<t[i]))/sum(lfdr<t[i])
  }
  
  q_bayesian <- rep(NA,G)
  
  for (g in 1:G){
    p_g <- lfdr[g]
    q_bayesian[g] <- FDR_t[which((t>=p_g)==T)[1]]
  }
  
  return(q_bayesian)
  
}
