GetGOoutput <-
function(DE.genes,All.genes,nodesize_lower,nodesize_upper,topnodes) {
  
  library(topGO)
  library(ALL)
  library("org.Rn.eg.db")
  
  all<-data.frame(gene=All.genes,de=rep(0,length(All.genes)) )
  rownames(all) <- All.genes
  all[DE.genes,2]<-1
  all_vec<-all[,2]
  names(all_vec)<-all[,1]
  
  topGenes= function (allScore) 
  {
    return(allScore ==1)
  }
  
  GOdata <- new("topGOdata",
                description = "GO Enrichment analysis", ontology = "BP",
                allGenes = all_vec, geneSel = topGenes,
                nodeSize = nodesize_lower,annot = annFUN.org,
                mapping = "org.Rn.eg.db",
                ID = "symbol")
  
  resultFisher <- runTest(GOdata, algorithm = "classic", statistic = "fisher")
  allRes <- GenTable(GOdata, classicFisher = resultFisher,
                     orderBy = "classicFisher", ranksOf = "classicFisher", topNodes =topnodes)
  
  allRes$Total_sig<-rep(numSigGenes(GOdata),nrow(allRes))
  allRes$Total_genes<-rep(numGenes(GOdata),nrow(allRes))
  allRes$odds_ratio<-(allRes$Significant*(allRes$Total_genes-allRes$Annotated-
                                            (allRes$Total_sig-allRes$Significant)  )) / 
    ((allRes$Total_sig-allRes$Significant)*(allRes$Annotated-allRes$Significant) )
  allRes$log_odds_ratio<-log(allRes$odds_ratio)
  
  annot_name<-vector('list',length=nrow(allRes))
  sig_name<-vector('list',length=nrow(allRes))
  
  for(i in 1:nrow(allRes)){
    print(i)
    GOid.of.interest = allRes[i,"GO.ID"]
    annot_name[[i]] <- genesInTerm(GOdata,GOid.of.interest)[[1]]
    sig_name[[i]] <-DE.genes[which(DE.genes %in% annot_name[[i]]==T)]
  }
  
  allRes$Annotate_genes<-rep(NA,nrow(allRes))
  allRes$Sig_genes<-rep(NA,nrow(allRes))
  for(i in 1:nrow(allRes)){
    allRes[i,'Annotate_genes']<- paste(annot_name[[i]],collapse=',')
    allRes[i,'Sig_genes']<- paste(as.character(sig_name[[i]]),collapse=',')
  }
  GO_out<-allRes[allRes[,'Annotated']<=nodesize_upper,]
  return(GO_out)
}
