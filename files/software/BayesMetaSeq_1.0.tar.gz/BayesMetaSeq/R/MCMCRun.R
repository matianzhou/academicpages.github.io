MCMCRun <-
function(Data.list,X.list,Init.value,Store.value,iteration,thin,
                    lambda_mean,lambda_var,eta_mean,eta_var,
                    m_mean,m_var,IG_alpha,IG_beta,pi_alpha,
                      epsilon_omega = 0.5, epsilon_phi = 0.5,
                     epsilon_log_phi = -0.5, cov_tune = 1e-3,seed=12345) {
  
library(BayesMetaSeq)
library(MCMCpack)
library(mvtnorm)
library(BayesLogit)
library(gtools)
library(gdata)
library(msm)
  
  mat.sqrt<-function(A)         #square root of a matrix
  {
    ei<-eigen(A)
    d<-ei$values
    d<-(d+abs(d))/2
    d2<-sqrt(d)
    ans<-ei$vectors %*% diag(d2) %*% t(ei$vectors)
    return(ans)
  }
  
  
  mat.sqrt.inv<-function(A)   #square root inverse of a matrix
  {
    ei<-eigen(A)
    d<-ei$values
    d<-(d+abs(d))/2
    d2<-1 / sqrt(d)
    d2[d == 0]<-0
    ans<-ei$vectors %*% diag(d2) %*% t(ei$vectors)
    return(ans)
  }
  
  rescale<-function(x,newrange) {
    if(nargs() > 1 && is.numeric(x) && is.numeric(newrange)) {
      # if newrange has max first, reverse it
      if(newrange[1] > newrange[2]) {
        newmin<-newrange[2]
        newrange[2]<-newrange[1]
        newrange[1]<-newmin
      }
      xrange<-range(x)
      if(xrange[1] == xrange[2]) stop("can't rescale a constant vector!")
      mfac<-(newrange[2]-newrange[1])/(xrange[2]-xrange[1])
      invisible(newrange[1]+(x-xrange[1])*mfac)
    }
    else {
      cat("Usage: rescale(x,newrange)\n")
      cat("\twhere x is a numeric object and newrange is the min and max of the new range\n")
    }
  }
  
  Store.value[["Cluster.Assign"]][,1]=Init.value[["Cluster.Assign"]]
  Store.value[["Prob.Cluster"]][[1]]=Init.value[["Prob.Cluster"]]
  Store.value[["Delta"]][,1]=Init.value[["Delta"]]
  Store.value[["Sigma2.DE"]][,1]=Init.value[["Sigma2.DE"]]
  Store.value[["Sigma2.Non.DE"]][,1]=Init.value[["Sigma2.Non.DE"]]
  Store.value[["Tau2"]][,1]=Init.value[["Tau2"]]
  Store.value[["Xi2"]][,1]=Init.value[["Xi2"]]
  Store.value[["Rho.DE"]][,1]=Init.value[["Rho.DE"]]
  Store.value[["Rho.Non.DE"]][,1]=Init.value[["Rho.Non.DE"]]
  Store.value[["RR"]][,1]=Init.value[["RR"]]
  Store.value[["TT"]][,1]=Init.value[["TT"]]
  Store.value[["Lambda"]][,1]=Init.value[["Lambda"]]
  Store.value[["Eta"]][,1]=Init.value[["Eta"]]
  Store.value[["M"]][,1]=Init.value[["M"]]
  Store.value[["Beta"]][,1]=Init.value[["Beta"]]
  Store.value[["Alpha"]][,1]=Init.value[["Alpha"]]
  Store.value[["LogPhi"]][,1]=Init.value[["LogPhi"]]
  Store.value[["Omega"]]=Init.value[["Omega"]]
  
  G <- sapply(Data.list,nrow)[1]  # number of genes
  N <- sapply(Data.list,ncol)    # number of samples
  K <- length(Data.list) # number of studies
  
  libsize <- lapply(Data.list,colSums)
  logT <- lapply(libsize,log)
  
  L<- 3^K ## number of motifs
  motif_template <- expand.grid(replicate(K,c(-1,0,1),simplify=F))
  
  v_alpha=v_beta=v_phi=K+1
  
  
  ##############################  
  ######### updating functions
  ##############################
  
  ### c.assign update function:
  
  update_c <- function(z.mat,c.assign,i) {
    
    ## delta.accum.mat is a matrix of G rows and L columns, every row would sum to thin (e.g. =50)
    
    cluster.pool<-c(unique(c.assign),max(unique(c.assign))+1)
    z.i <- z.mat[i,]
    
    prob.c <- sapply(unique(c.assign), FUN=function(x) {
      cluster.size <- length(which(c.assign==x))
      cluster.ind <- which(c.assign==x)
      if(cluster.size>1) {z.ave.cluster <- apply(z.mat[cluster.ind,],2,mean)} else{
        z.ave.cluster <- z.mat[cluster.ind,]}
      
      ifelse(cluster.size!=0, 
             ( (cluster.size-1) /(G-1+pi_alpha) ) * 
               dmvnorm(x=z.i,mean=(cluster.size/(cluster.size+1))*z.ave.cluster,sigma=diag((cluster.size+2)/(cluster.size+1),K),log=F) , 
             0)},simplify=T )
    
    
    
    prob.jump <- ( pi_alpha/(G-1+pi_alpha) ) *
      dmvnorm(x=z.i,mean=rep(0,K),sigma=diag(2,K),log=F)
    
    
    # prob.c is a vector of length = length(unique(c)) 
    std.prob <- c(prob.c,prob.jump)/(sum(prob.c)+prob.jump) 
    sample(cluster.pool,size=1,prob=std.prob)
  }
  
  ### pi update function: for all L clusters
  
  update_pi <- function(c) {
    result<-rdirichlet(n=1,alpha=as.vector(rep(pi_alpha,length(unique(c)))+table(c) ) )
    return(result)
  }
  
  
  #### alpha,beta update function:

  update_alphabeta <- function(y,lib,X.mat,omega,logphi,delta,lambda,eta,sigma2.de,sigma2.non.de,tau2) {
    
    Omega <- diag(omega)
    r <- 1/exp(logphi)
    
    c = c(eta,lambda*delta)
    C = diag(c(tau2,
               ifelse(delta==0,sigma2.non.de,sigma2.de) ) )
    
    V = solve(t(X.mat)%*%Omega%*% X.mat+solve(C)) 
    z = (y-r)/(2*omega) - lib
    m = V%*%(t(X.mat)%*%Omega%*%z + solve(C)%*%c)
    rmvnorm(n=1,mean=m,sigma=V)
  }
  
  #### logphi update function 
  
  update_logphi<- function(m,Pi,logphi,alpha,beta,X.list,y,lib) {
    
    y.k<-lapply(y,'[',g,,drop=F)
    
    sum.fun<-function(alpha,beta,X,logphi,lib,y){
      sum( dnbinom(y,size=ifelse(is.na(1/exp(logphi)),1/epsilon_phi,1/exp(logphi)),
                   mu=exp(lib+alpha+beta*X), log=T) )  
    }
    
    old_logp<-mapply(sum.fun,alpha=alpha,
                     beta=beta,X=X.list,logphi=logphi,
                     lib=lib,y=y.k)
    
    old_hyper<-ifelse(dmvnorm(logphi,mean=rep(m,K),sigma=Pi+cov_tune*diag(K), log=F)==0,
                      epsilon_phi,
                      dmvnorm(logphi,mean=rep(m,K),sigma=Pi+cov_tune*diag(K), log=T) )
    
    old_log_like  <- sum(old_logp) + old_hyper
    
    #new.logphi  <- rmvnorm(1,logphi,sigma=diag(diag(Pi)) )  # Proposal
    #new.logphi  <- rmvnorm(1,logphi,sigma=Pi )  # Proposal
    #if (any(new.logphi>=0)) {new.logphi[which(new.logphi>=0)]<-epsilon_log_phi}
    
    new.logphi <- rep(NA,length(logphi))
     for (i in 1:length(logphi)){
       new.logphi[i]<-rtnorm(1,mean=logphi[i],sd=sqrt(diag(Pi)[i]),lower=-Inf,upper=0)
    }
    
    new_logp<-mapply(sum.fun,alpha=alpha,
                     beta=beta,X=X.list,logphi=new.logphi,
                     lib=lib,y=y.k) 
    
    new_hyper<-ifelse(dmvnorm(new.logphi,mean=rep(m,K),sigma=Pi+cov_tune*diag(K), log=F)==0,
                      epsilon_phi,
                      dmvnorm(new.logphi,mean=rep(m,K),sigma=Pi+cov_tune*diag(K), log=T) )
    
    new_log_like  <- sum(new_logp) +new_hyper
    
    if(!is.na(new_log_like))  {
      if ( !is.na(old_log_like) ) {
        if ( !is.na(new_log_like - old_log_like) ){
          if(new_log_like - old_log_like > log(runif(1)) ) 
            return(new.logphi)
          else  return(logphi)
        }
        else return(logphi)
      }
      else return(new.logphi)
    }
    else return(logphi)
    
  }
  
  
  ### update lambda, eta, m 
  
  update_lambda<-function(beta,lambda,delta,Sigma) {
    
    old_logp<-dmvnorm(beta,mean=lambda*delta,sigma=Sigma+cov_tune*diag(K),log=T)
    
    old_hyper<-dnorm(lambda,mean=lambda_mean,sd=sqrt(lambda_var),log=T)
    
    old_log_like  <- old_logp + old_hyper
    
    new.lambda  <- rnorm(1,mean=lambda,sd=sqrt(lambda_var)) # Proposal
    
    new_logp<-dmvnorm(beta,mean=new.lambda*delta,sigma=Sigma+cov_tune*diag(K),log=T)
    
    new_hyper<-dnorm(new.lambda,mean=lambda_mean,sd=sqrt(lambda_var),log=T)
    
    new_log_like  <- new_logp + new_hyper
    
    if(!is.na(new_log_like))  {
      if ( !is.na(old_log_like) ) {
        if ( !is.na(new_log_like - old_log_like) ){
          if(new_log_like - old_log_like > log(runif(1)) ) 
            return(new.lambda)
          else  return(lambda)
        }
        else return(lambda)
      }
      else return(new.lambda)
    }
    else return(lambda)    
  } 
  
  update_eta<-function(alpha,eta,Lambda) {
    
    old_logp<-dmvnorm(alpha,mean=rep(eta,K),sigma=Lambda+cov_tune*diag(K),log=T)
    
    old_hyper<-dnorm(eta,mean=eta_mean,sd=sqrt(eta_var),log=T)
    
    old_log_like  <- old_logp + old_hyper
    
    new.eta  <- rnorm(1,mean=eta,sd=sqrt(eta_var)) # Proposal
    
    new_logp<-dmvnorm(alpha,mean=rep(new.eta,K),sigma=Lambda+cov_tune*diag(K),log=T)
    
    new_hyper<-dnorm(new.eta,mean=eta_mean,sd=sqrt(eta_var),log=T)
    
    new_log_like  <- new_logp + new_hyper
    
    if(!is.na(new_log_like))  {
      if ( !is.na(old_log_like) ) {
        if ( !is.na(new_log_like - old_log_like) ){
          if(new_log_like - old_log_like > log(runif(1)) ) 
            return(new.eta)
          else  return(eta)
        }
        else return(eta)
      }
      else return(new.eta)
    }
    else return(eta) 
  } 
  
  update_m<-function(logphi,m,Pi) {
    
    old_logp<-dmvnorm(logphi,mean=rep(m,K),sigma=Pi+cov_tune*diag(K),log=T)
    
    old_hyper<-dnorm(m,mean=m_mean,sd=sqrt(m_var),log=T)
    
    old_log_like  <- old_logp + old_hyper
    
    #new.m  <- rnorm(1,mean=m,sd=sqrt(m_var)) # Proposal
    #if (new.m>=0) {new.m<-epsilon_log_phi}
    new.m <- rtnorm(1,mean=m, sd=sqrt(m_var),upper=0)
     
    new_logp<-dmvnorm(logphi,mean=rep(new.m,K),sigma=Pi+cov_tune*diag(K),log=T)
    
    new_hyper<-dnorm(new.m,mean=m_mean,sd=sqrt(m_var),log=T)
    
    new_log_like  <- new_logp + new_hyper
    
    if(!is.na(new_log_like))  {
      if ( !is.na(old_log_like) ) {
        if ( !is.na(new_log_like - old_log_like) ){
          if(new_log_like - old_log_like > log(runif(1)) ) 
            return(new.m)
          else  return(m)
        }
        else return(m)
      }
      else return(new.m)
    }
    else return(m) 
  } 
  
  
  #### sigma2.beta, sigma2.alpha, sigma2.log.phi update functions
  
  update_sigma2de<-function(beta,lambda,delta){
    rinvgamma(1,shape=sum(delta)/2+IG_alpha,
              scale=(1/2)*sum((delta*(beta-lambda*delta)^2)[which(abs(beta)<5)] ) + IG_beta  )  
  }
  
  update_sigma2nonde<-function(beta,lambda,delta){
    rinvgamma(1,shape=(G-sum(delta))/2 + IG_alpha,
              scale=(1/2)*sum((beta[which(delta==0 & abs(beta)<5)])^2) + IG_beta  )  
  }
  
  update_tau2<-function(alpha,eta){
    rinvgamma(1,shape=G/2,
              scale=(1/2)*sum((alpha-eta)^2)  )
  }
  
  update_xi2 <-function(logphi,m){
    rinvgamma(1,shape=G/2,
              scale=(1/2)* sum((logphi-m)^2)  )
  }
  
  ##### rho, r, t update functions
  
  update_rho<-function(beta,lambda,v_beta,delta) {
    beta.i<-rep(0,K)
    lambda.i<-rep(mean(lambda),K)
    for (k in 1:K){
      beta.i[k]<-mean(beta[seq(k,length(beta),length(beta)/K)])
    }  
    Cov<-riwish(v=v_beta+K, S=diag(K)+matrix(beta.i-lambda.i) %*% t(matrix(beta.i-lambda.i))  )  #sum over G
    # then integrate out variance to get the correlation matrix
    Cor<-diag((x=diag(Cov))^(-1/2)) %*%
      Cov %*% diag((x=diag(Cov))^(-1/2))
    rho.out<-Cor[which(upper.tri(Cor)=='TRUE')]
    return(rho.out)
  }
  
  update_r<-function(alpha,eta,v_alpha) {
    alpha.i<-rep(0,K)
    eta.i<-rep(mean(eta),K)
    for (k in 1:K){
      alpha.i[k]<-mean(alpha[seq(k,K*G,G)])
    }  
    Cov<-riwish(v=v_alpha+K, S=diag(K)+ matrix(alpha.i-eta.i) %*% t(matrix(alpha.i-eta.i)) )   #sum over K
    # then integrate out variance to get the correlation matrix
    Cor<-diag((x=diag(Cov))^(-1/2)) %*%
      Cov %*% diag((x=diag(Cov))^(-1/2))
    r.out<-Cor[which(upper.tri(Cor)=='TRUE')]
    return(r.out)
  }
  
  
  update_t<-function(logphi,m,v_phi) {
    logphi.i<-rep(0,K)
    m.i<-rep(mean(m),K)
    for (k in 1:K){
      logphi.i[k]<-mean(logphi[seq(k,K*G,G)])
    }  
    Cov<-riwish(v=v_phi+K, S=diag(K)+matrix(logphi.i-m.i) %*% t(matrix(logphi.i-m.i)) )  #sum over K
    # then integrate out variance to get the correlation matrix
    Cor<-diag((x=diag(Cov))^(-1/2)) %*%
      Cov %*% diag((x=diag(Cov))^(-1/2))
    t.out<-Cor[which(upper.tri(Cor)=='TRUE')]
    return(t.out)
  }
  
  ### delta_beta update function
  
  update_deltabeta<- function(old.delta,old.beta,new.beta,
                              sigma2.de.i.k,
                              sigma2.non.de.i.k,y,X,lib,
                              alpha,logphi,lambda) {
    
    new.delta<-1-old.delta 
    
    old_logp= sum( dnbinom(y,size=ifelse(is.na(1/exp(logphi)),1/epsilon_phi,1/exp(logphi)),
                           mu=exp(lib+alpha+old.beta*X), log=T) ) +  
      dnorm(old.beta,mean=ifelse(old.delta==0,0,lambda),
    #        sd=sqrt(sigma2.non.de.i.k),log=T) 
           sd=ifelse(old.delta==0,sqrt(sigma2.non.de.i.k),sqrt(sigma2.de.i.k)),log=T) 
    
    new_logp= sum( dnbinom(y,size=ifelse(is.na(1/exp(logphi)),1/epsilon_phi,1/exp(logphi)),
                           mu=exp(lib+alpha+new.beta*X), log=T) ) +  
      dnorm(new.beta,mean=ifelse(new.delta==0,0,lambda),
    #        sd=sqrt(sigma2.non.de.i.k),log=T) 
               sd=ifelse(new.delta==0,sqrt(sigma2.non.de.i.k),sqrt(sigma2.de.i.k)),log=T) 
    
    old_log_like<-old_logp
    new_log_like<-new_logp
    
    if(!is.na(new_log_like))  {
      if ( !is.na(old_log_like) ) {
        if ( !is.na(new_log_like - old_log_like) ){
          
          if(new_log_like - old_log_like > log(runif(1)))
            return(c(new.delta,new.beta)) 
          else
            return(c(old.delta,old.beta)) 
        }
        else return (c(old.delta,old.beta))
      }
      else return (c(new.delta,new.beta))
    }
    else 
      return (c(old.delta,old.beta))
    
  }    
  
  
  ## list of library and count: for block update in the last step
  lib.g<-rep(logT,G)
  X.g<-rep(X.list,G)
  y.k.g<-vector('list',K*G)
  for (g in 1:G){
    for (k in 1:K){
      y.k.g[[(g-1)*K+k]]<-Data.list[[k]][g,]
    }
  }
  
  ## calculate the observed ES
  
  es_seq =function (y,X,lib) {
    y=array(y)
    v1=log((y[which(X==1)]+1)/(lib[which(X==1)]))
    v2=log((y[which(X==0)]+1)/(lib[which(X==0)]))
    u=mean(v1-v2)
    return(u)
  }
  
  beta.obs<-matrix(rep(0,G*K),nrow=G,ncol=K) 
  for (g in 1:G){
    for (k in 1:K){
      lib<-libsize[[k]]
      beta.obs[g,k]<-es_seq(y=Data.list[[k]][g,],X=X.list[[k]],lib=lib)
    }
  }
  
  
  ### Iteration part
  for (iter in 1:iteration) {   
    
    set.seed(seed+iter)
    
    startTime <- proc.time()
    
     iter <- iter + 1  
     if (iter>iteration) {
     	  print("MCMC iteration completed")
          out <- list(Store.value[['Delta']],Store.value[['Beta']], Store.value[['Cluster.Assign']])
          names(out) <- c("DE.Out","Beta.Out","Cluster.Assign.Out")
          return(out)
    }
    #if (iter>iteration) break
    # if (iter>iteration) {return(Store.value)}
    
    delta.old <- Store.value[['Delta']][,iter-1]
    beta.old<-Store.value[['Beta']][,iter-1]
    alpha.old<-Store.value[['Alpha']][,iter-1]
    logphi.old<-Store.value[['LogPhi']][,iter-1]
    
    lambda.old<-Store.value[['Lambda']][,iter-1]
    eta.old<-Store.value[['Eta']][,iter-1]
    m.old<-Store.value[['M']][,iter-1]
    
    sigma2.de.old<-Store.value[['Sigma2.DE']][,iter-1]
    sigma2.non.de.old<-Store.value[['Sigma2.Non.DE']][,iter-1]
    tau2.old<-Store.value[['Tau2']][,iter-1]
    xi2.old<-Store.value[['Xi2']][,iter-1]
    
    rho.de.old<-Store.value[['Rho.DE']][,iter-1]
    rho.non.de.old<-Store.value[['Rho.Non.DE']][,iter-1]
    r.old<-Store.value[['RR']][,iter-1]
    t.old<-Store.value[['TT']][,iter-1]
    
    omega.old <- Store.value[['Omega']]
    
    rho.cor.de.old<- matrix(,ncol=K,nrow=K) 
    rho.cor.non.de.old<- matrix(,ncol=K,nrow=K)  
    r.cor.old<- matrix(,ncol=K,nrow=K)
    t.cor.old<- matrix(,ncol=K,nrow=K)
    
    rho.cor.de.old[which(upper.tri(rho.cor.de.old)=='TRUE')]<-rho.de.old
    rho.cor.non.de.old[which(upper.tri(rho.cor.non.de.old)=='TRUE')]<-rho.non.de.old
    r.cor.old[which(upper.tri(r.cor.old)=='TRUE')]<-r.old
    t.cor.old[which(upper.tri(t.cor.old)=='TRUE')]<-t.old
        
    diag(rho.cor.de.old)<-rep(1,K)
    diag(rho.cor.non.de.old)<-rep(1,K)
    diag(r.cor.old)<-rep(1,K)
    diag(t.cor.old)<-rep(1,K)
    
    #Copy the upper diagonal portion to the lower portion
    
    #rho.cor.de.old<- rho.cor.de.old2; 
    #rho.cor.de.old[row(rho.cor.de.old2) >= col(rho.cor.de.old2)] <- t(rho.cor.de.old2)[row(rho.cor.de.old2) >= col(rho.cor.de.old2)] 
    #rho.cor.non.de.old<- rho.cor.non.de.old2; 
    #rho.cor.non.de.old[row(rho.cor.non.de.old2) >= col(rho.cor.non.de.old2)] <- t(rho.cor.non.de.old2)[row(rho.cor.non.de.old2) >= col(rho.cor.de.old2)] 
    #r.cor.old<- r.cor.old2; 
    #r.cor.old[row(r.cor.old2) >= col(r.cor.old2)] <- t(r.cor.old2)[row(r.cor.old2) >= col(r.cor.old2)] 
    #t.cor.old<- t.cor.old2; 
    #t.cor.old[row(t.cor.old2) >= col(t.cor.old2)] <- t(t.cor.old2)[row(t.cor.old2) >= col(t.cor.old2)] 
   
    #lowerTriangle(rho.cor.de.old,diag=F,byrow=T) <- upperTriangle(rho.cor.de.old)
    #lowerTriangle(rho.cor.non.de.old,diag=F,byrow=T) <- upperTriangle(rho.cor.non.de.old)
    #lowerTriangle(r.cor.old,diag=F,byrow=T) <- upperTriangle(r.cor.old)
    #lowerTriangle(t.cor.old,diag=F,byrow=T) <- upperTriangle(t.cor.old)
    
    rho.cor.de.old[lower.tri(rho.cor.de.old)] <- t(rho.cor.de.old)[lower.tri(rho.cor.de.old)]
    rho.cor.non.de.old[lower.tri(rho.cor.non.de.old)] <- t(rho.cor.non.de.old)[lower.tri(rho.cor.non.de.old)]    
    r.cor.old[lower.tri(r.cor.old)] <- t(r.cor.old)[lower.tri(r.cor.old)]
    t.cor.old[lower.tri(t.cor.old)] <- t(t.cor.old)[lower.tri(t.cor.old)]
    
    
    ### update c.assign and pi
    
    sign.vector<-c(apply(beta.obs,1,sign))
    
    if(iter %% thin==0) {
      
      rnd = iter/thin
      c.assign.old <- Store.value[['Cluster.Assign']][,rnd]
      prob.vector <- apply(Store.value[['Delta']][,(1+thin*(rnd-1)):(thin+thin*(rnd-1))]*sign.vector,1,mean)
      #scale.prob.vector <-  rescale(prob.vector,newrange=c(0,1))
      scale.prob.vector <-  (prob.vector+1)/2                                                             
      z.vec <- qnorm(scale.prob.vector) 
      z.vec[which(z.vec> 3)] <- 4
      z.vec[which(z.vec< -3)] <- -4
      z.mat <- matrix(z.vec,byrow=T,nrow=G,ncol=K)  ## observed data for clustering
      c.assign.cur<-rep(0,G)
      for (g in 1:G) {
        c.assign.cur[g]<-update_c(z.mat=z.mat,c.assign=c.assign.old, i=g)
      }
      #print(table(c.assign.cur))
      Store.value[['Cluster.Assign']][,rnd+1] <- c.assign.cur
      
    }
    
    ### update alpha+beta,logphi,lambda,eta,m 
    
    alpha.cur=rep(0,K*G)
    beta.cur=rep(0,K*G)
    beta.new=rep(0,K*G)
    logphi.cur=rep(0,K*G)
    lambda.cur=rep(0,G)
    eta.cur=rep(0,G)
    m.cur=rep(0,G) 
    
    Sigma.de<- mat.sqrt(diag(sigma2.de.old))%*% rho.cor.de.old %*% 
      mat.sqrt(diag(sigma2.de.old))
    Sigma.non.de<- mat.sqrt(diag(sigma2.non.de.old))%*% rho.cor.non.de.old %*% 
      mat.sqrt(diag(sigma2.non.de.old))
    Lambda <- mat.sqrt(diag(tau2.old))%*% r.cor.old %*% 
      mat.sqrt(diag(tau2.old))
    Pi <- mat.sqrt(diag(xi2.old))%*% t.cor.old %*% 
      mat.sqrt(diag(xi2.old))    
    
    omega.cur  <- omega.old
    
    for (g in 1:G) {
      
      delta.g<-delta.old[((g-1)*K+1):(g*K)]
      beta.g<- beta.old[((g-1)*K+1):(g*K)] 
      alpha.g<- alpha.old[((g-1)*K+1):(g*K)] 
      logphi.g<-logphi.old[((g-1)*K+1):(g*K)]
      lambda.g<-lambda.old[g]
      eta.g<- eta.old[g] 
      m.g<-m.old[g]  	
      
    for (k in 1:K) {
        X.mat <- cbind(rep(1,N[[k]]),X.list[[k]])
        alphabeta <- update_alphabeta(y=Data.list[[k]][g,],lib=logT[[k]],X.mat=X.mat,omega=omega.old[[k]][g,],logphi=logphi.g[k],delta=delta.g[k],lambda=lambda.g,eta=eta.g,sigma2.de=sigma2.de.old[k],sigma2.non.de=sigma2.non.de.old[k],tau2=tau2.old[k])
          alphabeta.new <- update_alphabeta(y=Data.list[[k]][g,],lib=logT[[k]],X.mat=X.mat,omega=omega.old[[k]][g,],logphi=logphi.g[k],delta=1-delta.g[k],lambda=lambda.g,eta=eta.g,sigma2.de=sigma2.de.old[k],sigma2.non.de=sigma2.non.de.old[k],tau2=tau2.old[k])  
           if(abs(alphabeta[2])>10) {
               alpha.cur[(g-1)*K+k] <- alpha.g[k]
               beta.cur[(g-1)*K+k] <- beta.g[k]
               beta.new[(g-1)*K+k] <- 10
               } else{   
          	alpha.cur[(g-1)*K+k] <- alphabeta[1]
        	beta.cur[(g-1)*K+k] <- alphabeta[2]
        	beta.new[(g-1)*K+k] <- alphabeta.new[2]
                }
          omega.cur[[k]][g,] <- rpg(num=N[[k]],h=Data.list[[k]][g,]+1/exp(logphi.g[k]),z=c( X.mat%*%c(alpha.cur[(g-1)*K+k],beta.cur[(g-1)*K+k]))+ logT[[k]] )
      	}
      	
     logphi.cur[((g-1)*K+1):(g*K)]<-update_logphi(m=m.g,Pi=Pi,logphi=logphi.g,alpha=alpha.cur[((g-1)*K+1):(g*K)],beta=beta.cur[((g-1)*K+1):(g*K)],X.list=X.list,y=Data.list,lib=logT)         
      
      if(sum(delta.g)==0) {

        lambda.cur[g]<-update_lambda(beta=beta.cur[((g-1)*K+1):(g*K)] ,lambda=lambda.g,delta=delta.g,Sigma=Sigma.non.de)	
        
      } else  {     

        lambda.cur[g]<-update_lambda(beta=beta.cur[((g-1)*K+1):(g*K)],lambda=lambda.g,delta=delta.g,Sigma=Sigma.de)	

      }

       eta.cur[g]<-update_eta(alpha=alpha.cur[((g-1)*K+1):(g*K)]  ,eta=eta.g,Lambda=Lambda)
      m.cur[g]<-update_m(logphi=logphi.cur[((g-1)*K+1):(g*K)],m=m.g,Pi=Pi)
               
    }
    
    Store.value[['Beta']][,iter]<-beta.cur    
    Store.value[['Alpha']][,iter]<-alpha.cur
    Store.value[['LogPhi']][,iter]<-logphi.cur      
    Store.value[['Lambda']][,iter]<-lambda.cur  
    Store.value[['Eta']][,iter]<-eta.cur
    Store.value[['M']][,iter]<-m.cur   
    Store.value[['Omega']] <- omega.cur 
    
    # update sigma2.beta, sigma2.alpha, sigma2.log.phi
    
    sigma2.de.cur<-rep(0,K)
    sigma2.non.de.cur<-rep(0,K)
    tau2.cur<-rep(0,K)
    xi2.cur<-rep(0,K)
    
    for (k in 1:K) {
      
      sigma2.de.cur[k]<-update_sigma2de(
        beta=beta.cur[seq(k,(G-1)*K+k,by=K)],lambda=lambda.cur,delta=delta.old[seq(k,(G-1)*K+k,by=K)])
      
      sigma2.non.de.cur[k]<-update_sigma2nonde(
        beta=beta.cur[seq(k,(G-1)*K+k,by=K)],lambda=lambda.cur,delta=delta.old[seq(k,(G-1)*K+k,by=K)])
      
      tau2.cur[k]<-update_tau2(
        alpha=alpha.cur[seq(k,(G-1)*K+k,by=K)],eta=eta.cur)
      
      xi2.cur[k]<-update_xi2(
        logphi=logphi.cur[seq(k,(G-1)*K+k,by=K)],m=m.cur)
    }
    
    Store.value[['Sigma2.DE']][,iter]<-sigma2.de.cur
    Store.value[['Sigma2.Non.DE']][,iter]<-sigma2.non.de.cur
    Store.value[['Tau2']][,iter]<-tau2.cur
    Store.value[['Xi2']][,iter]<-xi2.cur
    
    ### update rho, r, t
    beta.mat<-matrix(beta.cur,byrow=F,nrow=K,ncol=G)
    delta.mat<-matrix(delta.old,byrow=F,nrow=K,ncol=G)
    delta.sum<-apply(delta.mat,2,sum)
    de.index<-which(delta.sum>=1)
    non.de.index<-which(delta.sum==0)
    beta.de<-c(beta.mat[,de.index])
    beta.non.de<-c(beta.mat[,non.de.index])
    lambda.de<-lambda.cur[de.index]
    lambda.non.de<-lambda.cur[non.de.index]
    
    rho.de.cur<-update_rho(beta=beta.de,lambda=lambda.de,v_beta=v_beta)
    rho.non.de.cur<-update_rho(beta=beta.non.de,lambda=lambda.non.de,v_beta=v_beta)
    r.cur<-update_r(alpha=alpha.cur,eta=eta.cur,v_alpha=v_alpha)
    t.cur<-update_t(logphi=logphi.cur,m=m.cur,v_phi=v_phi)
    
    Store.value[['Rho.DE']][,iter]<-rho.de.cur 
    Store.value[['Rho.Non.DE']][,iter]<-rho.non.de.cur   
    Store.value[['RR']][,iter]<-r.cur 
    Store.value[['TT']][,iter]<-t.cur
    
    ## block update of delta and beta
    
    
    deltabeta.cur<-unlist(mapply(update_deltabeta,
                                 old.delta=delta.old,old.beta=beta.cur,
#                                 new.beta=beta.new,sigma2.de.i.k =sigma2.de.cur,
                                 new.beta=beta.cur,sigma2.de.i.k =sigma2.de.cur,sigma2.non.de.i.k=sigma2.non.de.cur,y=y.k.g,X=X.g,lib=lib.g,
                                 alpha=alpha.cur,logphi=logphi.cur,lambda=rep(lambda.cur,each=K)
    ))
    
    delta.cur<-deltabeta.cur[1,]
    beta.cur<-deltabeta.cur[2,]
    
    Store.value[['Delta']][,iter]<- delta.cur
    Store.value[['Beta']][,iter]<- beta.cur
    
    endTime <- proc.time()
    
    print(iter)
    print(endTime-startTime) 
#    print(range(alpha.cur))
#    print(range(beta.cur))
#    print(range(logphi.cur))
#    print(apply(Store.value[['Delta']][1:K,1:iter],1,mean) )

  }
  
}

